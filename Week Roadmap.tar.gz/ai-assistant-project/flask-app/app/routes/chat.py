from flask import Blueprint, request, jsonify
from app import db
from app.models import Conversation, Message
from app.services.llm_service import get_assistant_reply

chat_bp = Blueprint("chat", __name__, url_prefix="/api")


@chat_bp.route("/conversations", methods=["POST"])
def create_conversation():
    """Start a new conversation for a user."""
    data = request.get_json()
    conversation = Conversation(user_id=data["user_id"])
    db.session.add(conversation)
    db.session.commit()
    return jsonify({"conversation_id": conversation.id}), 201


@chat_bp.route("/conversations/<int:conversation_id>/messages", methods=["POST"])
def send_message(conversation_id):
    """
    The core loop: save the user's message, build history, call the LLM,
    save the reply, return it. This is Stage 2-4 from the architecture
    diagram in a single endpoint.
    """
    data = request.get_json()
    user_text = data["content"]

    conversation = Conversation.query.get_or_404(conversation_id)

    # 1. Save the incoming user message
    user_msg = Message(conversation_id=conversation.id, role="user", content=user_text)
    db.session.add(user_msg)
    db.session.commit()

    # 2. Build prompt: full message history in API format
    history = [m.to_api_format() for m in conversation.messages]

    # 3. Call the LLM
    reply_text = get_assistant_reply(history)

    # 4. Save and return the assistant's reply
    assistant_msg = Message(conversation_id=conversation.id, role="assistant", content=reply_text)
    db.session.add(assistant_msg)
    db.session.commit()

    return jsonify({"role": "assistant", "content": reply_text})


@chat_bp.route("/conversations/<int:conversation_id>/messages", methods=["GET"])
def get_messages(conversation_id):
    """Fetch full message history for a conversation (for rendering the UI)."""
    conversation = Conversation.query.get_or_404(conversation_id)
    return jsonify([m.to_api_format() for m in conversation.messages])
