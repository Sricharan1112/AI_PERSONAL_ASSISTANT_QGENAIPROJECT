from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from config import Config

db = SQLAlchemy()


def create_app(config_class=Config):
    """Application factory — lets you spin up the app with different
    configs for testing, dev, and prod without circular imports."""
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)

    # Register blueprints (route groups)
    from app.routes.chat import chat_bp
    app.register_blueprint(chat_bp)

    with app.app_context():
        db.create_all()

    return app
