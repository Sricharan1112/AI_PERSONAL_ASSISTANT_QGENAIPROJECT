import os
import anthropic

client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))

SYSTEM_PROMPT = (
    "You are a helpful AI assistant. Be concise and clear in your responses."
)


def get_assistant_reply(message_history):
    """
    message_history: list of dicts like [{"role": "user", "content": "..."}]
    Pulled straight from Message.to_api_format() in the calling route —
    that's why the messages table 'role' column matches the API's role names.
    """
    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1024,
        system=SYSTEM_PROMPT,
        messages=message_history,
    )
    return response.content[0].text
