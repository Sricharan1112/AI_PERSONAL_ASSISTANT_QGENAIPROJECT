from django.urls import path
from . import views

urlpatterns = [
    path("conversations", views.create_conversation, name="create_conversation"),
    path("conversations/<int:conversation_id>/messages", views.send_message, name="send_message"),
]

# Note: GET messages reuses the same path with a different HTTP method,
# which Django routes via require_http_methods inside the view rather than
# a second urlpattern. If you want a distinct URL instead, add it explicitly.
urlpatterns += [
    path("conversations/<int:conversation_id>/history", views.get_messages, name="get_messages"),
]
