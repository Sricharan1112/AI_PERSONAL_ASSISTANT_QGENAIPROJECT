import json
from django.http import JsonResponse, HttpResponseNotFound
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.shortcuts import get_object_or_404

from .models import Conversation, Message
from .services.llm_service import get_assistant_reply


@csrf_exempt
@require_http_methods(["POST"])
def create_conversation(request):
    """Start a new conversation for a user."""
    data = json.loads(request.body)
    conversation = Conversation.objects.create(user_id=data["user_id"])
    return JsonResponse({"conversation_id": conversation.id}, status=201)


@csrf_exempt
@require_http_methods(["POST"])
def send_message(request, conversation_id):
    """
    The core loop: save the user's message, build history, call the LLM,
    save the reply, return it. Same four stages as the Flask version —
    Django's ORM syntax differs, the workflow doesn't.
    """
    data = json.loads(request.body)
    user_text = data["content"]

    conversation = get_object_or_404(Conversation, id=conversation_id)

    # 1. Save the incoming user message
    Message.objects.create(conversation=conversation, role="user", content=user_text)

    # 2. Build prompt: full message history in API format
    history = [m.to_api_format() for m in conversation.messages.all()]

    # 3. Call the LLM
    reply_text = get_assistant_reply(history)

    # 4. Save and return the assistant's reply
    Message.objects.create(conversation=conversation, role="assistant", content=reply_text)

    return JsonResponse({"role": "assistant", "content": reply_text})


@require_http_methods(["GET"])
def get_messages(request, conversation_id):
    """Fetch full message history for a conversation."""
    conversation = get_object_or_404(Conversation, id=conversation_id)
    messages = [m.to_api_format() for m in conversation.messages.all()]
    return JsonResponse(messages, safe=False)
