import anthropic
from django.conf import settings

client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)

SYSTEM_PROMPT = (
    "You are a helpful AI assistant. Be concise and clear in your responses."
)


def get_assistant_reply(message_history):
    """
    message_history: list of dicts like [{"role": "user", "content": "..."}]
    Same contract as the Flask version — this function is framework-agnostic
    on purpose, so the prompt-building logic doesn't care which web framework
    is calling it.
    """
    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1024,
        system=SYSTEM_PROMPT,
        messages=message_history,
    )
    return response.content[0].text
