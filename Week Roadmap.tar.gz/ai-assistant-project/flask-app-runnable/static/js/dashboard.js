(function () {
  "use strict";

  const tableBodyEl = document.getElementById("conv-table-body");
  const statTotalEl = document.getElementById("stat-total");
  const statMessagesEl = document.getElementById("stat-messages");
  const statActiveEl = document.getElementById("stat-active");
  const newBtn = document.getElementById("dashboard-new-btn");

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function formatRelativeTime(isoString) {
    // SQLite CURRENT_TIMESTAMP is UTC without a 'Z' suffix — append it so
    // the browser parses it as UTC instead of local time.
    const date = new Date(isoString.replace(" ", "T") + "Z");
    const diffMs = Date.now() - date.getTime();
    const diffMin = Math.floor(diffMs / 60000);
    if (diffMin < 1) return "just now";
    if (diffMin < 60) return `${diffMin}m ago`;
    const diffHr = Math.floor(diffMin / 60);
    if (diffHr < 24) return `${diffHr}h ago`;
    const diffDay = Math.floor(diffHr / 24);
    return `${diffDay}d ago`;
  }

  async function loadDashboard() {
    const res = await fetch("/api/conversations");
    if (!res.ok) return;
    const conversations = await res.json();

    const totalMessages = conversations.reduce((sum, c) => sum + c.message_count, 0);
    const activeToday = conversations.filter((c) => {
      const updated = new Date(c.updated_at.replace(" ", "T") + "Z");
      return Date.now() - updated.getTime() < 24 * 60 * 60 * 1000;
    }).length;

    statTotalEl.textContent = conversations.length;
    statMessagesEl.textContent = totalMessages;
    statActiveEl.textContent = activeToday;

    if (conversations.length === 0) {
      tableBodyEl.innerHTML =
        '<div class="dashboard__empty">No conversations yet — start one to see it here.</div>';
      return;
    }

    tableBodyEl.innerHTML = conversations
      .map(
        (c) => `
        <div class="conv-row conv-row--body" data-id="${c.id}">
          <div class="conv-row__title">${escapeHtml(c.title)}</div>
          <div>${c.message_count} msgs</div>
          <div>${formatRelativeTime(c.updated_at)}</div>
          <button class="conv-row__delete" data-delete-id="${c.id}" aria-label="Delete conversation" title="Delete conversation">×</button>
        </div>`
      )
      .join("");

    tableBodyEl.querySelectorAll(".conv-row--body").forEach((row) => {
      row.addEventListener("click", (e) => {
        if (e.target.closest(".conv-row__delete")) return;
        window.location.href = `/chat/${row.dataset.id}`;
      });
    });

    tableBodyEl.querySelectorAll(".conv-row__delete").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.stopPropagation();
        const id = btn.dataset.deleteId;
        await fetch(`/api/conversations/${id}`, { method: "DELETE" });
        loadDashboard();
      });
    });
  }

  newBtn.addEventListener("click", async () => {
    const res = await fetch("/api/conversations", { method: "POST" });
    const data = await res.json();
    window.location.href = `/chat/${data.conversation_id}`;
  });

  loadDashboard();
})();
