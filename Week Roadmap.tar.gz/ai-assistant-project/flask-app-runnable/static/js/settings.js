(function () {
  "use strict";

  function showMsg(el, text, type) {
    el.textContent = text;
    el.className = `settings-msg is-visible settings-msg--${type}`;
  }

  function formatDate(isoString) {
    const date = new Date(isoString.replace(" ", "T") + "Z");
    return date.toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" });
  }

  // ---------- Load profile ----------

  let defaultSystemPrompt = "";

  async function loadProfile() {
    const res = await fetch("/api/settings/profile");
    if (!res.ok) return;
    const data = await res.json();

    document.getElementById("member-since").textContent = `member since ${formatDate(data.created_at)}`;
    document.getElementById("stat-conversations").textContent = data.conversation_count;
    document.getElementById("stat-messages").textContent = data.message_count;
    document.getElementById("stat-username").textContent = data.username;

    document.getElementById("new-username").placeholder = data.username;

    defaultSystemPrompt = data.default_system_prompt;
    const promptField = document.getElementById("system-prompt");
    promptField.value = data.system_prompt; // empty string if using the default
    promptField.placeholder = defaultSystemPrompt;
    document.getElementById("prompt-char-count").textContent = promptField.value.length;
  }

  // ---------- System prompt ----------

  const promptField = document.getElementById("system-prompt");
  const promptCount = document.getElementById("prompt-char-count");

  promptField.addEventListener("input", () => {
    promptCount.textContent = promptField.value.length;
  });

  document.getElementById("prompt-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const msgEl = document.getElementById("prompt-msg");
    const btn = document.getElementById("prompt-save");
    btn.disabled = true;

    try {
      const res = await fetch("/api/settings/system-prompt", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ system_prompt: promptField.value }),
      });
      const data = await res.json();
      if (!res.ok) {
        showMsg(msgEl, data.error, "error");
      } else {
        showMsg(msgEl, "Saved.", "success");
      }
    } catch (err) {
      showMsg(msgEl, "Could not reach the server", "error");
    } finally {
      btn.disabled = false;
    }
  });

  document.getElementById("prompt-reset").addEventListener("click", () => {
    promptField.value = "";
    promptCount.textContent = "0";
  });

  // ---------- Username ----------

  document.getElementById("username-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const msgEl = document.getElementById("username-msg");
    const btn = document.getElementById("username-save");
    const input = document.getElementById("new-username");
    btn.disabled = true;

    try {
      const res = await fetch("/api/settings/username", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: input.value.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        showMsg(msgEl, data.error, "error");
      } else {
        showMsg(msgEl, `Username updated to "${data.username}".`, "success");
        input.value = "";
        input.placeholder = data.username;
        document.getElementById("stat-username").textContent = data.username;
        document.querySelector(".status-bar__user").firstChild.textContent = data.username + " ";
      }
    } catch (err) {
      showMsg(msgEl, "Could not reach the server", "error");
    } finally {
      btn.disabled = false;
    }
  });

  // ---------- Password ----------

  document.getElementById("password-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const msgEl = document.getElementById("password-msg");
    const btn = document.getElementById("password-save");
    const currentInput = document.getElementById("current-password");
    const newInput = document.getElementById("new-password");
    btn.disabled = true;

    try {
      const res = await fetch("/api/settings/password", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          current_password: currentInput.value,
          new_password: newInput.value,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showMsg(msgEl, data.error, "error");
      } else {
        showMsg(msgEl, "Password updated.", "success");
        currentInput.value = "";
        newInput.value = "";
      }
    } catch (err) {
      showMsg(msgEl, "Could not reach the server", "error");
    } finally {
      btn.disabled = false;
    }
  });

  // ---------- Delete account ----------

  const deleteBtn = document.getElementById("delete-account-btn");
  const deleteConfirm = document.getElementById("delete-confirm");
  const deleteCancelBtn = document.getElementById("delete-cancel-btn");
  const deleteConfirmBtn = document.getElementById("delete-confirm-btn");
  const deletePasswordInput = document.getElementById("delete-password");

  deleteBtn.addEventListener("click", () => {
    deleteConfirm.classList.add("is-visible");
    deleteBtn.style.display = "none";
  });

  deleteCancelBtn.addEventListener("click", () => {
    deleteConfirm.classList.remove("is-visible");
    deleteBtn.style.display = "";
    deletePasswordInput.value = "";
  });

  deleteConfirmBtn.addEventListener("click", async () => {
    const msgEl = document.getElementById("delete-msg");
    deleteConfirmBtn.disabled = true;

    try {
      const res = await fetch("/api/settings/account", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: deletePasswordInput.value }),
      });
      if (res.status === 204) {
        window.location.href = "/signup";
        return;
      }
      const data = await res.json();
      showMsg(msgEl, data.error, "error");
    } catch (err) {
      showMsg(msgEl, "Could not reach the server", "error");
    } finally {
      deleteConfirmBtn.disabled = false;
    }
  });

  loadProfile();
})();
