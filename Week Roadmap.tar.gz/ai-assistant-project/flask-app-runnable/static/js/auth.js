(function () {
  "use strict";

  const formEl = document.getElementById("auth-form");
  const errorEl = document.getElementById("auth-error");
  const submitBtn = document.getElementById("auth-submit");
  const endpoint = formEl.dataset.endpoint; // '/api/auth/login' or '/api/auth/signup'

  function showError(message) {
    errorEl.textContent = message;
    errorEl.classList.add("is-visible");
  }

  formEl.addEventListener("submit", async (e) => {
    e.preventDefault();
    errorEl.classList.remove("is-visible");
    submitBtn.disabled = true;

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value;

    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();

      if (!res.ok) {
        showError(data.error || "Something went wrong");
        submitBtn.disabled = false;
        return;
      }

      window.location.href = "/";
    } catch (err) {
      showError("Could not reach the server");
      submitBtn.disabled = false;
    }
  });
})();
