(function () {
  "use strict";

  const conversationId = window.__CONVERSATION_ID__; // set by chat.html, may be null
  const scrollEl = document.getElementById("chat-scroll");
  const formEl = document.getElementById("composer-form");
  const inputEl = document.getElementById("composer-input");
  const sendBtn = document.getElementById("composer-send");
  const sidebarListEl = document.getElementById("sidebar-list");

  let activeConversationId = conversationId;

  // ---------- Utilities ----------

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function scrollToBottom() {
    scrollEl.scrollTop = scrollEl.scrollHeight;
  }

  function renderMarkdown(text) {
    // marked converts markdown -> HTML; DOMPurify strips anything unsafe
    // before it touches the DOM (script tags, event handler attrs, etc).
    // Both libs are optional CDN loads — fall back to plain text if either
    // failed to load (offline dev, ad blocker, etc).
    if (typeof marked === "undefined" || typeof DOMPurify === "undefined") {
      return escapeHtml(text);
    }
    const rawHtml = marked.parse(text, { breaks: true });
    return DOMPurify.sanitize(rawHtml);
  }

  function autoResize() {
    inputEl.style.height = "auto";
    inputEl.style.height = Math.min(inputEl.scrollHeight, 200) + "px";
  }

  // ---------- Rendering ----------

  function clearEmptyState() {
    const empty = scrollEl.querySelector(".chat-empty-state");
    if (empty) empty.remove();
  }

  function renderMessage(role, content, { streaming = false } = {}) {
    clearEmptyState();
    const wrap = document.createElement("div");
    wrap.className = `message message--${role}`;

    const tag = document.createElement("div");
    tag.className = `message__tag message__tag--${role}`;
    tag.textContent = role;

    const body = document.createElement("div");
    body.className = "message__body" + (streaming ? " is-streaming" : "");

    if (role === "assistant" && !streaming) {
      body.innerHTML = renderMarkdown(content);
    } else {
      // User messages and the "Thinking…" placeholder stay as plain text —
      // no reason to parse markdown out of what the user typed, and the
      // placeholder has no markdown in it anyway.
      body.textContent = content;
    }

    wrap.appendChild(tag);
    wrap.appendChild(body);
    scrollEl.appendChild(wrap);
    scrollToBottom();
    return body;
  }

  function renderError(text) {
    clearEmptyState();
    const wrap = document.createElement("div");
    wrap.className = "message";
    const err = document.createElement("div");
    err.className = "message__error";
    err.textContent = `error: ${text}`;
    wrap.appendChild(err);
    scrollEl.appendChild(wrap);
    scrollToBottom();
  }

  // ---------- API calls ----------

  async function ensureConversation() {
    if (activeConversationId) return activeConversationId;
    const res = await fetch("/api/conversations", { method: "POST" });
    if (!res.ok) throw new Error("Could not create conversation");
    const data = await res.json();
    activeConversationId = data.conversation_id;
    // Update the URL without a full reload so refresh keeps context
    window.history.replaceState({}, "", `/chat/${activeConversationId}`);
    return activeConversationId;
  }

  async function loadHistory(id) {
    const res = await fetch(`/api/conversations/${id}/messages`);
    if (!res.ok) return;
    const messages = await res.json();
    if (messages.length === 0) return;
    clearEmptyState();
    messages.forEach((m) => renderMessage(m.role, m.content));
  }

  async function sendMessage(text) {
    const id = await ensureConversation();
    renderMessage("user", text);

    const thinkingBody = renderMessage("assistant", "Thinking…", { streaming: true });

    try {
      const res = await fetch(`/api/conversations/${id}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: text }),
      });

      if (!res.ok) {
        const errBody = await res.json().catch(() => ({}));
        throw new Error(errBody.error || `Request failed (${res.status})`);
      }

      const data = await res.json();
      thinkingBody.innerHTML = renderMarkdown(data.content);
      thinkingBody.classList.remove("is-streaming");
    } catch (err) {
      thinkingBody.parentElement.remove();
      renderError(err.message);
    }
  }

  // ---------- Sidebar ----------

  async function loadSidebar() {
    if (!sidebarListEl) return;
    const res = await fetch("/api/conversations");
    if (!res.ok) return;
    const conversations = await res.json();

    if (conversations.length === 0) {
      sidebarListEl.innerHTML = '<div class="sidebar__empty">No conversations yet</div>';
      return;
    }

    sidebarListEl.innerHTML = conversations
      .map((c) => {
        const activeClass = c.id === activeConversationId ? " is-active" : "";
        return `<a class="sidebar__item${activeClass}" href="/chat/${c.id}">${escapeHtml(c.title)}</a>`;
      })
      .join("");
  }

  // ---------- Events ----------

  formEl.addEventListener("submit", async (e) => {
    e.preventDefault();
    const text = inputEl.value.trim();
    if (!text) return;

    inputEl.value = "";
    autoResize();
    sendBtn.disabled = true;

    await sendMessage(text);

    sendBtn.disabled = false;
    inputEl.focus();
    loadSidebar(); // refresh titles/ordering after the exchange
  });

  inputEl.addEventListener("input", autoResize);

  inputEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      formEl.requestSubmit();
    }
  });

  // ---------- Init ----------

  if (activeConversationId) {
    loadHistory(activeConversationId);
  }
  loadSidebar();
  inputEl.focus();
})();
