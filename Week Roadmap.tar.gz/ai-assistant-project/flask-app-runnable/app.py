"""
Minimal runnable version of the Week 1-2 AI Assistant — no extra pip
installs needed beyond Flask itself (which ships in most Python
environments).

Uses:
- sqlite3 (standard library) instead of SQLAlchemy
- urllib.request (standard library) instead of the anthropic package
- hashlib + secrets (standard library) instead of a password-hashing library
- Flask's built-in session (signed cookies) instead of Flask-Login

This is for testing the end-to-end flow locally. The fuller flask-app/
version (SQLAlchemy + anthropic SDK) is what you'd actually build on.
"""
import os
import sqlite3
import json
import re
import hashlib
import secrets
import urllib.request
import urllib.error
from functools import wraps
from flask import Flask, request, jsonify, g, render_template, session, redirect, url_for

DB_PATH = os.path.join(os.path.dirname(__file__), "app.db")
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY")
DEFAULT_SYSTEM_PROMPT = "You are a helpful AI assistant. Be concise and clear."

app = Flask(__name__, static_folder="static", template_folder="templates")
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-in-production")


# ---------- Database ----------

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            salt TEXT NOT NULL,
            system_prompt TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT DEFAULT 'New conversation',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            conversation_id INTEGER NOT NULL,
            role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
            content TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_conversations_user_id ON conversations(user_id);
    """)
    conn.commit()
    conn.close()


# ---------- Auth helpers ----------
#
# Passwords are hashed with PBKDF2-HMAC-SHA256 (hashlib.pbkdf2_hmac), which
# ships in the Python standard library — no bcrypt/argon2 install needed.
# A random per-user salt (secrets.token_hex) means two users with the same
# password get different hashes, and precomputed rainbow-table attacks don't
# work against this database.

PBKDF2_ITERATIONS = 260_000
USERNAME_RE = re.compile(r"^[a-zA-Z0-9_]{3,30}$")


def hash_password(password, salt=None):
    if salt is None:
        salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), bytes.fromhex(salt), PBKDF2_ITERATIONS
    )
    return digest.hex(), salt


def verify_password(password, salt, expected_hash):
    computed_hash, _ = hash_password(password, salt)
    # secrets.compare_digest avoids leaking timing information about how
    # much of the hash matched — a plain == here would be a timing side
    # channel (small, but free to avoid).
    return secrets.compare_digest(computed_hash, expected_hash)


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            if request.path.startswith("/api/"):
                return jsonify({"error": "Not logged in"}), 401
            return redirect(url_for("login_page"))
        return view(*args, **kwargs)
    return wrapped


def current_user_id():
    return session.get("user_id")


# ---------- LLM call (raw HTTP, no SDK needed) ----------

def call_anthropic(message_history, system_prompt=DEFAULT_SYSTEM_PROMPT):
    if not ANTHROPIC_API_KEY:
        raise RuntimeError(
            "ANTHROPIC_API_KEY is not set. Run: export ANTHROPIC_API_KEY=sk-ant-..."
        )

    payload = {
        "model": "claude-sonnet-4-6",
        "max_tokens": 1024,
        "system": system_prompt or DEFAULT_SYSTEM_PROMPT,
        "messages": message_history,
    }
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read())
            return data["content"][0]["text"]
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        raise RuntimeError(f"Anthropic API error {e.code}: {body}")


# ---------- Page routes (serve the frontend) ----------

@app.route("/")
@login_required
def index():
    return render_template("dashboard.html")


@app.route("/chat")
@app.route("/chat/<int:conversation_id>")
@login_required
def chat_page(conversation_id=None):
    return render_template("chat.html", conversation_id=conversation_id)


@app.route("/settings")
@login_required
def settings_page():
    return render_template("settings.html")


@app.route("/login")
def login_page():
    if "user_id" in session:
        return redirect(url_for("index"))
    return render_template("login.html")


@app.route("/signup")
def signup_page():
    if "user_id" in session:
        return redirect(url_for("index"))
    return render_template("signup.html")


# ---------- Auth API routes ----------

@app.route("/api/auth/signup", methods=["POST"])
def signup():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""

    if not USERNAME_RE.match(username):
        return jsonify({"error": "Username must be 3-30 characters: letters, numbers, underscore only"}), 400
    if len(password) < 8:
        return jsonify({"error": "Password must be at least 8 characters"}), 400

    db = get_db()
    existing = db.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()
    if existing:
        return jsonify({"error": "That username is already taken"}), 409

    password_hash, salt = hash_password(password)
    cur = db.execute(
        "INSERT INTO users (username, password_hash, salt) VALUES (?, ?, ?)",
        (username, password_hash, salt),
    )
    db.commit()

    session["user_id"] = cur.lastrowid
    session["username"] = username
    return jsonify({"user_id": cur.lastrowid, "username": username}), 201


@app.route("/api/auth/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""

    db = get_db()
    user = db.execute(
        "SELECT id, username, password_hash, salt FROM users WHERE username = ?",
        (username,),
    ).fetchone()

    # Same generic error whether the username doesn't exist or the password
    # is wrong — confirming "that username exists" to an anonymous caller is
    # a (small) information leak, so the message stays identical either way.
    if not user or not verify_password(password, user["salt"], user["password_hash"]):
        return jsonify({"error": "Invalid username or password"}), 401

    session["user_id"] = user["id"]
    session["username"] = user["username"]
    return jsonify({"user_id": user["id"], "username": user["username"]})


@app.route("/api/auth/logout", methods=["POST"])
def logout():
    session.clear()
    return "", 204


@app.route("/api/auth/me", methods=["GET"])
def me():
    if "user_id" not in session:
        return jsonify({"error": "Not logged in"}), 401
    return jsonify({"user_id": session["user_id"], "username": session["username"]})


# ---------- Settings API routes ----------

@app.route("/api/settings/profile", methods=["GET"])
@login_required
def get_profile():
    """Account info + stats for the settings page."""
    db = get_db()
    user = db.execute(
        "SELECT username, system_prompt, created_at FROM users WHERE id = ?",
        (current_user_id(),),
    ).fetchone()

    counts = db.execute("""
        SELECT COUNT(DISTINCT c.id) AS conversation_count,
               COUNT(m.id) AS message_count
        FROM conversations c
        LEFT JOIN messages m ON m.conversation_id = c.id
        WHERE c.user_id = ?
    """, (current_user_id(),)).fetchone()

    return jsonify({
        "username": user["username"],
        "system_prompt": user["system_prompt"] or "",
        "default_system_prompt": DEFAULT_SYSTEM_PROMPT,
        "created_at": user["created_at"],
        "conversation_count": counts["conversation_count"],
        "message_count": counts["message_count"],
    })


@app.route("/api/settings/username", methods=["PUT"])
@login_required
def update_username():
    data = request.get_json(silent=True) or {}
    new_username = (data.get("username") or "").strip()

    if not USERNAME_RE.match(new_username):
        return jsonify({"error": "Username must be 3-30 characters: letters, numbers, underscore only"}), 400

    db = get_db()
    existing = db.execute(
        "SELECT id FROM users WHERE username = ? AND id != ?",
        (new_username, current_user_id()),
    ).fetchone()
    if existing:
        return jsonify({"error": "That username is already taken"}), 409

    db.execute(
        "UPDATE users SET username = ? WHERE id = ?", (new_username, current_user_id())
    )
    db.commit()

    session["username"] = new_username
    return jsonify({"username": new_username})


@app.route("/api/settings/password", methods=["PUT"])
@login_required
def update_password():
    data = request.get_json(silent=True) or {}
    current_password = data.get("current_password") or ""
    new_password = data.get("new_password") or ""

    if len(new_password) < 8:
        return jsonify({"error": "New password must be at least 8 characters"}), 400

    db = get_db()
    user = db.execute(
        "SELECT password_hash, salt FROM users WHERE id = ?", (current_user_id(),)
    ).fetchone()

    # Require the current password before allowing a change — without this,
    # anyone who finds an unattended logged-in session could lock the real
    # owner out by changing the password without knowing it.
    if not verify_password(current_password, user["salt"], user["password_hash"]):
        return jsonify({"error": "Current password is incorrect"}), 401

    new_hash, new_salt = hash_password(new_password)
    db.execute(
        "UPDATE users SET password_hash = ?, salt = ? WHERE id = ?",
        (new_hash, new_salt, current_user_id()),
    )
    db.commit()
    return jsonify({"status": "ok"})


@app.route("/api/settings/system-prompt", methods=["PUT"])
@login_required
def update_system_prompt():
    data = request.get_json(silent=True) or {}
    new_prompt = (data.get("system_prompt") or "").strip()

    if len(new_prompt) > 2000:
        return jsonify({"error": "System prompt must be 2000 characters or fewer"}), 400

    db = get_db()
    # Empty string means "use the default" — store NULL rather than "" so
    # DEFAULT_SYSTEM_PROMPT stays the single source of truth for the default
    # text instead of it being duplicated into every user's row.
    db.execute(
        "UPDATE users SET system_prompt = ? WHERE id = ?",
        (new_prompt or None, current_user_id()),
    )
    db.commit()
    return jsonify({"system_prompt": new_prompt or DEFAULT_SYSTEM_PROMPT})


@app.route("/api/settings/account", methods=["DELETE"])
@login_required
def delete_account():
    data = request.get_json(silent=True) or {}
    password = data.get("password") or ""

    db = get_db()
    user = db.execute(
        "SELECT password_hash, salt FROM users WHERE id = ?", (current_user_id(),)
    ).fetchone()

    if not verify_password(password, user["salt"], user["password_hash"]):
        return jsonify({"error": "Password is incorrect"}), 401

    # Cascades to conversations -> messages via the FK ON DELETE CASCADE
    db.execute("DELETE FROM users WHERE id = ?", (current_user_id(),))
    db.commit()
    session.clear()
    return "", 204


# ---------- API routes ----------

@app.route("/api/conversations", methods=["POST"])
@login_required
def create_conversation():
    db = get_db()
    cur = db.execute(
        "INSERT INTO conversations (user_id) VALUES (?)", (current_user_id(),)
    )
    db.commit()
    return jsonify({"conversation_id": cur.lastrowid}), 201


@app.route("/api/conversations", methods=["GET"])
@login_required
def list_conversations():
    """Powers both the dashboard and the chat sidebar — every conversation
    belonging to the logged-in user, most recently active first, with a
    message count for the dashboard."""
    db = get_db()
    rows = db.execute("""
        SELECT c.id, c.title, c.created_at, c.updated_at,
               COUNT(m.id) AS message_count
        FROM conversations c
        LEFT JOIN messages m ON m.conversation_id = c.id
        WHERE c.user_id = ?
        GROUP BY c.id
        ORDER BY c.updated_at DESC
    """, (current_user_id(),)).fetchall()
    return jsonify([dict(r) for r in rows])


def get_owned_conversation_or_404(db, conversation_id):
    """Fetch a conversation only if it belongs to the logged-in user.
    Returns None if it doesn't exist OR belongs to someone else — the two
    cases are deliberately indistinguishable to the caller, so one user
    can't probe which conversation IDs exist for another user."""
    return db.execute(
        "SELECT id FROM conversations WHERE id = ? AND user_id = ?",
        (conversation_id, current_user_id()),
    ).fetchone()


@app.route("/api/conversations/<int:conversation_id>", methods=["DELETE"])
@login_required
def delete_conversation(conversation_id):
    db = get_db()
    if not get_owned_conversation_or_404(db, conversation_id):
        return jsonify({"error": "Conversation not found"}), 404
    db.execute("DELETE FROM conversations WHERE id = ?", (conversation_id,))
    db.commit()
    return "", 204


@app.route("/api/conversations/<int:conversation_id>/messages", methods=["POST"])
@login_required
def send_message(conversation_id):
    db = get_db()
    if not get_owned_conversation_or_404(db, conversation_id):
        return jsonify({"error": "Conversation not found"}), 404

    data = request.get_json()
    user_text = data["content"]

    # Auto-title the conversation from its first message (dashboard needs
    # something better than "New conversation" for every row)
    existing_count = db.execute(
        "SELECT COUNT(*) AS n FROM messages WHERE conversation_id = ?",
        (conversation_id,),
    ).fetchone()["n"]
    if existing_count == 0:
        title = user_text[:50] + ("…" if len(user_text) > 50 else "")
        db.execute(
            "UPDATE conversations SET title = ? WHERE id = ?", (title, conversation_id)
        )

    # 1. Save user message
    db.execute(
        "INSERT INTO messages (conversation_id, role, content) VALUES (?, 'user', ?)",
        (conversation_id, user_text),
    )
    db.execute(
        "UPDATE conversations SET updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        (conversation_id,),
    )
    db.commit()

    # 2. Build history in API format
    rows = db.execute(
        "SELECT role, content FROM messages WHERE conversation_id = ? ORDER BY created_at",
        (conversation_id,),
    ).fetchall()
    history = [{"role": r["role"], "content": r["content"]} for r in rows]

    # 3. Call the LLM, using this user's custom system prompt if they set one
    user_row = db.execute(
        "SELECT system_prompt FROM users WHERE id = ?", (current_user_id(),)
    ).fetchone()
    system_prompt = user_row["system_prompt"] if user_row else None

    try:
        reply_text = call_anthropic(history, system_prompt)
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 502

    # 4. Save and return assistant reply
    db.execute(
        "INSERT INTO messages (conversation_id, role, content) VALUES (?, 'assistant', ?)",
        (conversation_id, reply_text),
    )
    db.execute(
        "UPDATE conversations SET updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        (conversation_id,),
    )
    db.commit()

    return jsonify({"role": "assistant", "content": reply_text})


@app.route("/api/conversations/<int:conversation_id>/messages", methods=["GET"])
@login_required
def get_messages(conversation_id):
    db = get_db()
    if not get_owned_conversation_or_404(db, conversation_id):
        return jsonify({"error": "Conversation not found"}), 404
    rows = db.execute(
        "SELECT role, content, created_at FROM messages WHERE conversation_id = ? ORDER BY created_at",
        (conversation_id,),
    ).fetchall()
    return jsonify([dict(r) for r in rows])


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "api_key_configured": bool(ANTHROPIC_API_KEY)})


if __name__ == "__main__":
    init_db()
    print(f"DB initialized at {DB_PATH}")
    print(f"ANTHROPIC_API_KEY configured: {bool(ANTHROPIC_API_KEY)}")
    app.run(debug=True, port=5000)
